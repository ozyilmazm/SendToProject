﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Odbc;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Odbc_Messages
{
    public enum ReportType { last_hour = 1, last_day = 2, last_week = 3 }

    static class HIS_ODBC
    {
        private static string connectionstring;
        private static OdbcConnection cnn;
        private static string command, StartDate, EndDate;


        public static bool Connect()
        {
            OdbcConnectionStringBuilder connectionStringBuilder = new OdbcConnectionStringBuilder();

            connectionStringBuilder.Dsn = "PowerHIS";
            connectionStringBuilder.Add("Uid", "odbcadm");
            connectionStringBuilder.Add("Pwd", "ODBC.Admin1");
            connectionstring = connectionStringBuilder.ConnectionString;
            cnn = new OdbcConnection(connectionstring);
            try
            {
                cnn.Open();
                Log.Print($"ODBC Connection state : {cnn.State}");
                return true;
            }
            catch (Exception e)
            {
                Log.Print(e.ToString());
                Console.WriteLine("Program has encountered an error! \nFor details please look the log file.");
                System.Threading.Thread.Sleep(5000);
                return false;
            }
        }


        public static void GetMessages(ReportType reportType)
        {
            
            
            List<Tuple<string, string, string, string, string, int>> messageList = new List<Tuple<string, string, string, string, string, int>>(); // Path1, Path2, Path3, Path4, Path5, Count
            int count = 1;
            if (reportType == ReportType.last_hour)
            {
                EndDate = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss");
                StartDate = DateTime.UtcNow.AddHours(-1).ToString("yyyy-MM-dd HH:mm:ss");
            }
            else if (reportType == ReportType.last_day)
            {
                EndDate = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss");
                StartDate = DateTime.UtcNow.AddDays(-1).ToString("yyyy-MM-dd HH:mm:ss");
            }
            else if (reportType == ReportType.last_week)
            {
                EndDate = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss");
                StartDate = DateTime.UtcNow.AddDays(-7).ToString("yyyy-MM-dd HH:mm:ss");
            }
            command = "SELECT Messages.Timestamp, Messages.Path, Messages.Path1, Messages.Path2, Messages.Path3, Messages.Path4, Messages.Path5, Messages.Status"
                    + " FROM Messages Messages"
                    + " WHERE(Messages.Timestamp >={ts '" + StartDate + "'} And Messages.Timestamp <={ts '" + EndDate + "'}) AND(Messages.Status Like 'App') AND(Messages.Indicator Like '%Alarm%')"
                    + " ORDER BY Messages.Timestamp";

            OdbcCommand odbcCommand = new OdbcCommand(command, cnn);


            OdbcDataReader reader = odbcCommand.ExecuteReader();
            Console.WriteLine("ODBC Okundu");

            DataTable dataTable = new DataTable();

            try
            {

                dataTable.Load(reader);
                Console.WriteLine("data table'a yazıldı");


            }
            catch (Exception e)
            {

                Log.Print(e.ToString());
            }
            Console.WriteLine("sorgu yapılacak");
            var query = dataTable.AsEnumerable().GroupBy(r => new { Path = r.Field<string>("Path"),
                                                                    Path1 = r.Field<string>("Path1"),
                                                                    Path2 = r.Field<string>("Path2"),
                                                                    Path3 = r.Field<string>("Path3"),
                                                                    Path4 = r.Field<string>("Path4"),
                                                                    Path5 = r.Field<string>("Path5")
                                                                   })
                                  .Select(grp => new
                                  {
                                      Path = grp.Key.Path,
                                      Path1 = grp.Key.Path1,
                                      Path2 = grp.Key.Path2,
                                      Path3 = grp.Key.Path3,
                                      Path4 = grp.Key.Path4,
                                      Path5 = grp.Key.Path5,
                                      Count = grp.Count()
                                  });
            Console.WriteLine("sorgu yapıldı");
            foreach (var item in query)
            {
                messageList.Add(Tuple.Create(item.Path1,item.Path2,item.Path3,item.Path4,item.Path5,item.Count));
            }

            Export.ExcelExport(messageList);
            reader.Close();
            cnn.Close();


        }
    }
}
