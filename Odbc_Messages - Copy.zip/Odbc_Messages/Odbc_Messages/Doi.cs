﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Interop.CdaDoi;
namespace Odbc_Messages
{
    class Doi
    {
        public static CxCdaDoiConnection doiConnection;
        public static Dictionary<string, string> substationOM;
        public static void Connect()
        {
            try
            {
                doiConnection = new CxCdaDoiConnection();
                doiConnection.Connect("PSOS", "RT");
            }
            catch (Exception e)
            {

                throw e;
            }
        }
        public static void FillSubstations()
        {
            CxCdaDoiCommand DoiCommand;
            DoiCommand = doiConnection.GetCommandObj();
            DoiCommand.AddPrimaryType("Substation", 0);
            DoiCommand.AddAttribute("Substation.Path");
            substationOM = new Dictionary<string, string>();

            CxCdaDoiRecordset QueryResult;
            QueryResult = doiConnection.GetCdaDoiRecordset(DoiCommand);

            while (QueryResult.IsEOF() == 0)
            {
                try
                {
                    substationOM.Add(QueryResult.GetAttribute("Substation.Path").Split('/')[2], QueryResult.GetAttribute("Substation.Path").Split('/')[1]);
                }
                catch (ArgumentException)
                {
                }
                QueryResult.MoveNext();
            }


        }



    }
}
