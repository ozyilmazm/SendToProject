﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace Quality
{
    static class Export
    {
        public static string filtertext { get; set; }
        public static void ExcelExport(List<Station> stations)
        {
            String ExportFileName;
            string FileName, TemplatePath;
            DateTime ExportDate = DateTime.Now;
            FileName = $"DataQualityReport_Filter{filtertext}";

            //TemplatePath = @"D:\RAPORLAR\StationQuality\Template\DataQuality.xlsx";
            TemplatePath = @"C:\Users\SPCAdmin\Desktop\Mete\Quality\DataQuality.xlsx";
            Excel.Application Template = null;
            Excel.Workbooks xDocuments = null;
            Excel.Workbook xDocument = null;
            Excel.Sheets Pages = null;
            Excel.Worksheet Page = null;

            Template = new Excel.Application();
            xDocuments = Template.Workbooks;
            xDocument = xDocuments.Open(@TemplatePath);
            if (xDocument != null)
            {
                Pages = xDocument.Worksheets;
                Page = (Excel.Worksheet)Pages["DATA"];
                try
                {
                    foreach (var obj in stations)
                    {
                        Range line = (Range)Page.Rows[2];
                        line.Insert();
                        Page.Cells[2, 2] = obj.Path;
                        Page.Cells[2, 3] = obj.Total;
                        Page.Cells[2, 4] = obj.Valid;
                        Page.Cells[2, 5] = obj.Invalid;
                        Page.Cells[2, 6] = obj.NotUpdated;
                    }
                }
                catch(Exception e)
                {
                    MessageBox.Show(e.ToString());
                }
                string xPath = @"C:\Users\SPCAdmin\Desktop\Mete\Quality\Report";
                if (!Directory.Exists(@xPath))
                {
                    Directory.CreateDirectory(@xPath);
                }
                Console.WriteLine(xPath);
                xPath = xPath + @"\" + ExportDate.Month;
                if (!Directory.Exists(xPath))
                {
                    Directory.CreateDirectory(xPath);
                }
                Console.WriteLine(xPath);
                if (System.IO.File.Exists(xPath + @"\" + FileName + ".xlsx"))
                {
                    System.IO.File.Delete(xPath + @"\" + FileName + ".xlsx");
                }
                xDocument.SaveAs(xPath + @"\" + FileName + ".xlsx");
                xDocument.Close(0);
                Template.Quit();
                Marshal.ReleaseComObject(Page);
                Marshal.ReleaseComObject(Pages);
                Marshal.ReleaseComObject(xDocument);
                Marshal.ReleaseComObject(xDocuments);
                Marshal.ReleaseComObject(Template);
                var result = MessageBox.Show
                    (
                    "Export alındı. \n Yeni bir sorgulama yapmak ister misiniz?",
                    "OK",
                    MessageBoxButtons.YesNo
                    );
                switch (result)
                {
                    case DialogResult.No:
                        System.Windows.Forms.Application.Exit();
                        break;
                    default:
                        break;
                }
            }
            else
            {
                MessageBox.Show("Template dokümanı bulunamadı/açılamadı.");
            }
        }

    }
}
