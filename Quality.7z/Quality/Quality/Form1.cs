﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Interop.CdaDoi;
using Interop.ScadaScripting;
using ASRNSClientLib;
using Interop.SPCSystemConfiguration;

namespace Quality
{
    
    public partial class Form1 : Form
    {
        
        public static CxCdaDoiConnection Connection;
        
        public Form1()
        {
            InitializeComponent();

        }

        public void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                Connection = new CxCdaDoiConnection();
                Connection.Connect("PSOS", "RT");
                DORConnectionOK.Checked = true;
               

            }
            catch (Exception)
            {
                DORConnectionOK.Checked = false;
            }

            try
            {
                ScadaScriptComponent scada = new ScadaScriptComponentClass();
                scada.ConsoleName = Environment.MachineName;
                scada.UserName = Environment.UserName;
                scada.ContextName = "RT";
                scada.SetActive(1);
                ScadaConnectOK.Checked = true;
            }
            catch (Exception)
            {
                ScadaConnectOK.Checked = false;
            }
            NameService.init();

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void statusStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            listView1.Items.Clear();
            if (Filter.Text.Length <= 0)
            {
                MessageBox.Show("Lütfen bir filtre giriniz.");
            }
            else
            {
                Export.filtertext = Filter.Text;
                CxCdaDoiCommand DoiCommand;
                DoiCommand = Connection.GetCommandObj();
                DoiCommand.AddPrimaryType("Substation", 0);
                DoiCommand.AddAttribute("Substation.Path");
                DoiCommand.AddAttribute("Substation.ObjectID");


                CxCdaDoiRecordset QueryResult;
                QueryResult = Connection.GetCdaDoiRecordset(DoiCommand);


                while (QueryResult.IsEOF() == 0)
                {

                    if (QueryResult.GetAttribute("Substation.Path").Contains(Filter.Text))
                    {
                        Station station = new Station(QueryResult.GetAttribute("Substation.ObjectID"), QueryResult.GetAttribute("Substation.Path"));
                        station.QualityCounter();
                        ListViewItem listitem = new ListViewItem(station.ObjId);
                        listitem.SubItems.Add(station.Path);
                        listitem.SubItems.Add(station.Total.ToString());
                        listitem.SubItems.Add(station.Valid.ToString());
                        listitem.SubItems.Add(station.Invalid.ToString());
                        listitem.SubItems.Add(station.NotUpdated.ToString());
                        if (station.Total > 0)
                        {
                            listitem.SubItems.Add($"%{((station.Valid / station.Total) * 100).ToString()}");
                        }
                        else
                        {
                            listitem.SubItems.Add("0");
                        }
                        
                        listView1.Items.Add(listitem);

                        //ListViewItem listitem = new ListViewItem(QueryResult.GetAttribute("Substation.ObjectID"));
                        //listitem.SubItems.Add(QueryResult.GetAttribute("Substation.Path"));
                        //listView1.Items.Add(listitem);
                    }
                    QueryResult.MoveNext();
                }
            }


        }

        private void ExportToExcelButton(object sender, EventArgs e)
        {
            if (listView1.Items.Count > 0)
            {
                int selected = listView1.SelectedItems.Count;
                List<Station> stationsx = new List<Station>();
                for (int i = 0; i < selected; i++)
                {
                    stationsx.Add(new Station(listView1.SelectedItems[i].Text,listView1.SelectedItems[i].SubItems[1].Text));
                }
                Export.ExcelExport(stationsx);
            }
            else
            {
                MessageBox.Show("Herhangi bir filtre girilmemiş. Boş liste exportu alınamaz.");
            }
        }

        private void Filter_TextChanged(object sender, EventArgs e)
        {

        }
    }


}

