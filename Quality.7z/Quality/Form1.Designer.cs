﻿namespace Quality
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.ColumnHeader StatıonPath;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Filter = new System.Windows.Forms.TextBox();
            this.ScadaConnectOK = new System.Windows.Forms.CheckBox();
            this.DORConnectionOK = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.listView1 = new System.Windows.Forms.ListView();
            this.ObjId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Total = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Valid = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Invalid = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.NotUpdated = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Health = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.button_Excel = new System.Windows.Forms.Button();
            StatıonPath = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // StatıonPath
            // 
            StatıonPath.Text = "Substations";
            StatıonPath.Width = 365;
            // 
            // Filter
            // 
            this.Filter.AllowDrop = true;
            this.Filter.Location = new System.Drawing.Point(12, 22);
            this.Filter.Name = "Filter";
            this.Filter.Size = new System.Drawing.Size(439, 20);
            this.Filter.TabIndex = 0;
            this.Filter.TextChanged += new System.EventHandler(this.Filter_TextChanged);
            // 
            // ScadaConnectOK
            // 
            this.ScadaConnectOK.AutoCheck = false;
            this.ScadaConnectOK.AutoSize = true;
            this.ScadaConnectOK.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ScadaConnectOK.ForeColor = System.Drawing.SystemColors.ControlText;
            this.ScadaConnectOK.Location = new System.Drawing.Point(632, 25);
            this.ScadaConnectOK.Name = "ScadaConnectOK";
            this.ScadaConnectOK.Size = new System.Drawing.Size(126, 17);
            this.ScadaConnectOK.TabIndex = 3;
            this.ScadaConnectOK.Text = "ScadaConnectionOK";
            this.ScadaConnectOK.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ScadaConnectOK.UseVisualStyleBackColor = true;
            // 
            // DORConnectionOK
            // 
            this.DORConnectionOK.AutoCheck = false;
            this.DORConnectionOK.AutoSize = true;
            this.DORConnectionOK.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.DORConnectionOK.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.DORConnectionOK.Location = new System.Drawing.Point(633, 48);
            this.DORConnectionOK.Name = "DORConnectionOK";
            this.DORConnectionOK.Size = new System.Drawing.Size(125, 18);
            this.DORConnectionOK.TabIndex = 3;
            this.DORConnectionOK.Text = "DORConnectionOK";
            this.DORConnectionOK.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.DORConnectionOK.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(457, 22);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(82, 20);
            this.button1.TabIndex = 5;
            this.button1.Text = "Filtre";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // listView1
            // 
            this.listView1.BackgroundImageTiled = true;
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ObjId,
            StatıonPath,
            this.Total,
            this.Valid,
            this.Invalid,
            this.NotUpdated,
            this.Health});
            this.listView1.FullRowSelect = true;
            this.listView1.GridLines = true;
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(12, 72);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(808, 338);
            this.listView1.Sorting = System.Windows.Forms.SortOrder.Ascending;
            this.listView1.TabIndex = 6;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // ObjId
            // 
            this.ObjId.Text = "ObjId";
            this.ObjId.Width = 0;
            // 
            // Total
            // 
            this.Total.Text = "TotalSignals";
            this.Total.Width = 73;
            // 
            // Valid
            // 
            this.Valid.Text = "ValidSignals";
            this.Valid.Width = 75;
            // 
            // Invalid
            // 
            this.Invalid.Text = "InvalidSignals";
            this.Invalid.Width = 81;
            // 
            // NotUpdated
            // 
            this.NotUpdated.Text = "Not Updated Signals";
            this.NotUpdated.Width = 149;
            // 
            // Health
            // 
            this.Health.Text = "Health";
            // 
            // button_Excel
            // 
            this.button_Excel.BackColor = System.Drawing.Color.Transparent;
            this.button_Excel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button_Excel.Image = ((System.Drawing.Image)(resources.GetObject("button_Excel.Image")));
            this.button_Excel.Location = new System.Drawing.Point(826, 380);
            this.button_Excel.Name = "button_Excel";
            this.button_Excel.Size = new System.Drawing.Size(30, 30);
            this.button_Excel.TabIndex = 8;
            this.button_Excel.UseVisualStyleBackColor = false;
            this.button_Excel.Click += new System.EventHandler(this.ExportToExcelButton);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(910, 450);
            this.Controls.Add(this.button_Excel);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.DORConnectionOK);
            this.Controls.Add(this.ScadaConnectOK);
            this.Controls.Add(this.Filter);
            this.Name = "Form1";
            this.Text = "Quality Report";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox Filter;
        private System.Windows.Forms.CheckBox ScadaConnectOK;
        private System.Windows.Forms.CheckBox DORConnectionOK;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Button button_Excel;
        private System.Windows.Forms.ColumnHeader ObjId;
        private System.Windows.Forms.ColumnHeader Total;
        private System.Windows.Forms.ColumnHeader Valid;
        private System.Windows.Forms.ColumnHeader Invalid;
        private System.Windows.Forms.ColumnHeader NotUpdated;
        private System.Windows.Forms.ColumnHeader Health;
    }
}

