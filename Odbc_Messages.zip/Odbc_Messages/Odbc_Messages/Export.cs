﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;

namespace Odbc_Messages
{
    static class Export
    {
        public static string filtertext { get; set; }
        public static void ExcelExport(List<Tuple<string, string, string, string, string, int>> report)
        {

            string FileName, TemplatePath;
            DateTime ExportDate = DateTime.Now;
            DirectorySecurity securityRules = new DirectorySecurity();
            securityRules.AddAccessRule(new FileSystemAccessRule("Users", FileSystemRights.FullControl, AccessControlType.Allow));

            string ExePath = System.Reflection.Assembly.GetEntryAssembly().Location.Replace(System.AppDomain.CurrentDomain.FriendlyName, "");
            int selected_count = report.Count;

            FileName = $"AlarmCountReport_{DateTime.Now.Year.ToString()}-{DateTime.Now.Month.ToString()}-{DateTime.Now.Day.ToString()}-{DateTime.Now.Hour.ToString()}-{DateTime.Now.Minute.ToString()}";

            TemplatePath = ExePath + "Template.xlsx";
            Excel.Application Template = null;
            Excel.Workbooks xDocuments = null;
            Excel.Workbook xDocument = null;
            Excel.Sheets Pages = null;
            Excel.Worksheet Page_Report = null;
            Excel.Worksheet Page_CFEChannels = null;
            Excel.Worksheet Page_RTUs = null;

            Template = new Excel.Application();
            xDocuments = Template.Workbooks;
            xDocument = xDocuments.Open(@TemplatePath);
            if (xDocument != null)
            {
                Pages = xDocument.Worksheets;
                Page_Report = (Excel.Worksheet)Pages["Report"];
                Page_CFEChannels = (Excel.Worksheet)Pages["CFEChannels"];
                Page_RTUs = (Excel.Worksheet)Pages["RTUs"];

                try
                {
                    foreach (var obj in report)
                    {
                        if (obj.Item4 == "...Failure")
                        {
                            if (obj.Item1.Contains("CFE"))
                            {
                                Excel.Range line = (Excel.Range)Page_CFEChannels.Rows[2];
                                line.Insert();
                                Page_CFEChannels.Cells[2, 3] = obj.Item1; // Path1
                                Page_CFEChannels.Cells[2, 4] = obj.Item2; //Path2
                                Page_CFEChannels.Cells[2, 5] = obj.Item3; //Path3
                                Page_CFEChannels.Cells[2, 6] = obj.Item4; //Path4
                                Page_CFEChannels.Cells[2, 7] = obj.Item5; //Path5
                                Page_CFEChannels.Cells[2, 8] = obj.Item6; //Count
                            }
                            else
                            {
                                Excel.Range line = (Excel.Range)Page_RTUs.Rows[2];
                                line.Insert();
                                Page_RTUs.Cells[2, 3] = obj.Item1; // Path1
                                Page_RTUs.Cells[2, 4] = obj.Item2; //Path2
                                Page_RTUs.Cells[2, 5] = obj.Item3; //Path3
                                Page_RTUs.Cells[2, 6] = obj.Item4; //Path4
                                Page_RTUs.Cells[2, 7] = obj.Item5; //Path5
                                Page_RTUs.Cells[2, 8] = obj.Item6; //Count
                            }

                        }
                        else
                        {
                            Excel.Range line = (Excel.Range)Page_Report.Rows[2];
                            line.Insert();
                            Page_Report.Cells[2, 2] = Doi.substationOM[obj.Item1]; // OM
                            Page_Report.Cells[2, 3] = obj.Item1; // Path1
                            Page_Report.Cells[2, 4] = obj.Item2; //Path2
                            Page_Report.Cells[2, 5] = obj.Item3; //Path3
                            Page_Report.Cells[2, 6] = obj.Item4; //Path4
                            Page_Report.Cells[2, 7] = obj.Item5; //Path5
                            Page_Report.Cells[2, 8] = obj.Item6; //Count
                        }


                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.ToString());
                }

                string xPath = ExePath + "Report";

                if (!Directory.Exists(@xPath))
                {

                    Directory.CreateDirectory(@xPath, securityRules);
                }

                xPath = xPath + @"\" + ExportDate.Month;
                if (!Directory.Exists(xPath))
                {
                    Directory.CreateDirectory(xPath, securityRules);
                }

                if (System.IO.File.Exists(xPath + @"\" + FileName + ".xlsx"))
                {
                    System.IO.File.Delete(xPath + @"\" + FileName + ".xlsx");
                }
                xDocument.SaveAs(xPath + @"\" + FileName + ".xlsx");
                xDocument.Close(0);
                Template.Quit();

                Marshal.ReleaseComObject(Page_Report);
                Marshal.ReleaseComObject(Pages);
                Marshal.ReleaseComObject(xDocument);
                Marshal.ReleaseComObject(xDocuments);
                Marshal.ReleaseComObject(Template);

                Process.Start(xPath + @"\" + FileName + ".xlsx");
            }
            else
            {
                Console.WriteLine("Template dokümanı bulunamadı/açılamadı.");
            }
        }

    }
}
