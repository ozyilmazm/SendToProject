﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;

namespace Odbc_Messages
{
    static class Export
    {
        public static string filtertext { get; set; }
        public static void ExcelExport(List<Tuple<string, string, string, string, string, int>> report, List<Tuple<string, string, string, string, string, int>> report_CFE, List<Tuple<string, string, string, string, string, int>> report_RTU)
        {

            string FileName, TemplatePath;
            DateTime ExportDate = DateTime.Now;
            DirectorySecurity securityRules = new DirectorySecurity();
            securityRules.AddAccessRule(new FileSystemAccessRule("Users", FileSystemRights.FullControl, AccessControlType.Allow));

            string ExePath = System.Reflection.Assembly.GetEntryAssembly().Location.Replace(System.AppDomain.CurrentDomain.FriendlyName, "");
            int i;
            
            FileName = $"AlarmCountReport-{HIS_ODBC.secim}_{DateTime.Now.Year.ToString()}-{DateTime.Now.Month.ToString()}-{DateTime.Now.Day.ToString()}-{DateTime.Now.Hour.ToString()}-{DateTime.Now.Minute.ToString()}";

            TemplatePath = ExePath + "Template.xlsx";
            Excel.Application Template = null;
            Excel.Workbooks xDocuments = null;
            Excel.Workbook xDocument = null;
            Excel.Sheets Pages = null;
            Excel.Worksheet Page_Report = null;
            Excel.Worksheet Page_CFEChannels = null;
            Excel.Worksheet Page_RTUs = null;

            Template = new Excel.Application();
            xDocuments = Template.Workbooks;
            xDocument = xDocuments.Open(@TemplatePath);
            if (xDocument != null)
            {
                Pages = xDocument.Worksheets;
                Page_Report = (Excel.Worksheet)Pages["Report"];
                Page_CFEChannels = (Excel.Worksheet)Pages["CFEChannels"];
                Page_RTUs = (Excel.Worksheet)Pages["RTUs"];

                i = 2;
                foreach (var obj in report)
                {
                    
                    try
                    {
                        Page_Report.Cells[i, 1] = Doi.substationOM[obj.Item1].Item2; // Project
                        Page_Report.Cells[i, 2] = Doi.substationOM[obj.Item1].Item1; // OM
                        Page_Report.Cells[i, 3] = obj.Item1; // Path1
                        if (obj.Item2.Contains('/'))
                        {
                            Page_Report.Cells[i, 4] = obj.Item2.Split('/')[0]; //Voltage Level
                            Page_Report.Cells[i, 5] = obj.Item2.Split('/')[1]; ; //Path2
                        }
                        else
                        {
                            Page_Report.Cells[i, 5] = obj.Item2; //Path2
                        }
                        
                        Page_Report.Cells[i, 6] = obj.Item3; //Path3
                        Page_Report.Cells[i, 7] = obj.Item4; //Path4
                        Page_Report.Cells[i, 8] = obj.Item5; //Path5
                        Page_Report.Cells[i, 9] = obj.Item6; //Count
                        i++;

                    }
                    catch (Exception e)
                    {
                        Log.Print(obj.Item1 + "/" + obj.Item2 + "/" + obj.Item3 + "/" + obj.Item4 + "/" + obj.Item5 + "/" + obj.Item6);
                        Log.Print(e.ToString());
                    }
                }
                i = 2;
                foreach (var obj in report_CFE)
                {
                    try
                    {
                        Page_CFEChannels.Cells[i, 1] = obj.Item1; // Path1
                        Page_CFEChannels.Cells[i, 2] = obj.Item2; //Path2
                        Page_CFEChannels.Cells[i, 3] = obj.Item3; //Path3
                        Page_CFEChannels.Cells[i, 4] = obj.Item4; //Path4
                        Page_CFEChannels.Cells[i, 5] = obj.Item6; //Count
                        i++;
                    }
                    catch (Exception e)
                    {
                        Log.Print(e.ToString());
                    }

                }
                i = 2;
                foreach (var obj in report_RTU)
                {
                    try
                    {
                        Page_RTUs.Cells[i, 1] = obj.Item1; // Path1
                        Page_RTUs.Cells[i, 2] = obj.Item4; //Path4
                        Page_RTUs.Cells[i, 3] = obj.Item6; //Count
                        i++;
                    }
                    catch (Exception e)
                    {
                        Log.Print(e.ToString());

                    }
                    
                }
                Page_Report.Columns.AutoFit();
                Page_Report.UsedRange.Sort(Page_Report.Columns[9], Excel.XlSortOrder.xlDescending);
                Page_RTUs.Columns.AutoFit();
                Page_RTUs.UsedRange.Sort(Page_RTUs.Columns[3], Excel.XlSortOrder.xlDescending);
                Page_CFEChannels.Columns.AutoFit();
                Page_CFEChannels.UsedRange.Sort(Page_CFEChannels.Columns[5], Excel.XlSortOrder.xlDescending);
                
                string xPath = ExePath + "Report";

                if (!Directory.Exists(@xPath))
                {

                    Directory.CreateDirectory(@xPath, securityRules);
                }

                xPath = xPath + @"\" + ExportDate.Month;
                if (!Directory.Exists(xPath))
                {
                    Directory.CreateDirectory(xPath, securityRules);
                }

                if (System.IO.File.Exists(xPath + @"\" + FileName + ".xlsx"))
                {
                    System.IO.File.Delete(xPath + @"\" + FileName + ".xlsx");
                }
                xDocument.SaveAs(xPath + @"\" + FileName + ".xlsx");
                xDocument.Close(0);
                Template.Quit();

                Marshal.ReleaseComObject(Page_Report);
                Marshal.ReleaseComObject(Pages);
                Marshal.ReleaseComObject(xDocument);
                Marshal.ReleaseComObject(xDocuments);
                Marshal.ReleaseComObject(Template);

                Process.Start(xPath + @"\" + FileName + ".xlsx");
            }
            else
            {
                Console.WriteLine("Template dokümanı bulunamadı/açılamadı.");
            }
        }

    }
}
