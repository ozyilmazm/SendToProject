﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odbc_Messages
{
    static class Log
    {
        public static string ExePath, ExeName, LogPath;

        private static void LogFolders()
        {

            int Index;
            ExePath = System.Reflection.Assembly.GetEntryAssembly().Location;
            Index = ExePath.LastIndexOf("\\");
            ExeName = ExePath.Substring(ExePath.LastIndexOf("\\") + 1);
            ExeName = ExeName.Replace(".exe", "");
            ExePath = ExePath.Remove(ExePath.LastIndexOf("\\") + 1);
            LogPath = ExePath + ExeName + " Logs";

            if (!Directory.Exists(LogPath))
            {
                Directory.CreateDirectory(LogPath);
            }

        }
        public static void Print(string LogState)
        {
            LogFolders();
            if (!Directory.Exists(LogPath))
            {
                Directory.CreateDirectory(LogPath);
            }

            string LogFile = LogPath + "/" + DateTime.Now.Year + "-" + DateTime.Now.Month + "-" + DateTime.Now.Day + ".txt";
            StreamWriter Writer = new StreamWriter(LogFile, true);
            LogState = DateTime.Now + " " + LogState;
            Writer.WriteLine(LogState);
            Writer.Close();
            Writer = null;
        }
    }
}
