﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Interop.CdaDoi;
namespace Odbc_Messages
{
    class Doi
    {
        public static CxCdaDoiConnection doiConnection;
        public static Dictionary<string, Tuple<string, string>> substationOM;
        private static string OM, path1;
        private static string projectName = " ";
        public static void Connect()
        {
            try
            {
                doiConnection = new CxCdaDoiConnection();
                doiConnection.Connect("PSOS", "RT");
            }
            catch (Exception e)
            {

                throw e;
            }
        }
        public static void FillSubstations()
        {
            CxCdaDoiCommand DoiCommand;
            DoiCommand = doiConnection.GetCommandObj();
            DoiCommand.AddPrimaryType("Substation", 0);
            DoiCommand.AddAttribute("Substation.Path");
            DoiCommand.AddAttribute("Substation.ProjectName");
            substationOM = new Dictionary<string, Tuple<string,string>>();
            /*
            CxCdaDoiCommand DoiCommandMeas;
            DoiCommandMeas = doiConnection.GetCommandObj();
            DoiCommandMeas.AddPrimaryType("Measurement", 1);
            DoiCommandMeas.AddAttribute("Measurement.Path");
            DoiCommandMeas.AddAttribute("Measurement.MessageConfiguration");
            */
            CxCdaDoiRecordset QueryResult;
            QueryResult = doiConnection.GetCdaDoiRecordset(DoiCommand);
            Console.WriteLine(DoiCommand.ToString());
            while (QueryResult.IsEOF() == 0)
            {
                try
                {
                    path1 = QueryResult.GetAttribute("Substation.Path").Split('/')[2];
                    OM = QueryResult.GetAttribute("Substation.Path").Split('/')[1];
                    try
                    {
                        projectName = QueryResult.GetAttribute("Substation.ProjectName");
                    }
                    catch (Exception)
                    {
                        projectName = " ";


                    }                                      
                    substationOM.Add(path1, Tuple.Create<string,string>(OM,projectName));
                }
                catch (ArgumentException)
                {
                }
                QueryResult.MoveNext();
            }
            /*
            CxCdaDoiRecordset QueryResultMeas;
            QueryResultMeas = doiConnection.GetCdaDoiRecordset(DoiCommandMeas);
            while (QueryResultMeas.IsEOF() == 0)
            {
                try
                {
                    Console.WriteLine($"{QueryResultMeas.GetAttribute("Measurement.Path")} --- {QueryResultMeas.GetAttribute("Measurement.MessageConfiguration")}"); 
                }
                catch (Exception e )
                {
                    Console.WriteLine(e.ToString());
                }
                QueryResultMeas.MoveNext();
            }
            */
        }



    }
}
