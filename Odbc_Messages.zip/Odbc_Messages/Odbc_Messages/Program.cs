﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Odbc;

namespace Odbc_Messages
{
    class Program
    {

        
        static void Main(string[] args)
        {
            if (HIS_ODBC.Connect())
            {
                Doi.Connect();
                Doi.FillSubstations();
                Console.WriteLine("bağlandı");
                if (args.Length > 0)
                {
                    switch (args[0])
                    {
                        case "Saat":
                            HIS_ODBC.GetMessages(ReportType.last_hour);
                            
                            break;
                        case "Gun":
                            HIS_ODBC.GetMessages(ReportType.last_day);
                            
                            break;
                        case "Hafta":
                            HIS_ODBC.GetMessages(ReportType.last_week);
                           
                            break;
                        default:
                            HIS_ODBC.GetMessages(ReportType.last_hour);
                           
                            break;
                    }
                }
                else
                {
                    HIS_ODBC.GetMessages(ReportType.last_hour);
                }
                System.Threading.Thread.Sleep(5000);
            }



        }
    }
}
