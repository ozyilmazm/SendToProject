﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Odbc;

namespace Odbc_Messages
{
    class Program
    {
       

        static void Main(string[] args)
        {
            if (HIS_ODBC.Connect())
            {
                Doi.Connect();
                Doi.FillSubstations();
                Console.WriteLine("bağlandı");                
                HIS_ODBC.GetMessages(ReportType.last_week);
                Console.ReadLine();
            }



        }
    }
}
