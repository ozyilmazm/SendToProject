﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quality
{
    class Station
    {
        public string Path { get; set; }
        public string ObjId { get; set; }
        public int Total { get; set; }
        public int Valid { get; set; }
        public int NotUpdated { get; set; }
        public int Invalid { get; set; }

        
        public Dictionary<string, Signal> signals;
        public Station(string objid, string path)
        {
            this.ObjId = objid;
            this.Path = path;
            signals = new Dictionary<string, Signal>();

            foreach (var item in NameService.ChildObjectAna(ObjId))
            {
                signals.Add(item, new Signal("Analog",item));
            }
            foreach (var item in NameService.ChildObjectDigi(ObjId))
            {
                signals.Add(item, new Signal("Discrete", item));
            }
            this.Total = signals.Count();

        }
        public void QualityCounter()
        {
            foreach (var item in signals.Values)
            {
                switch (item.Quality)
                {
                    case "Telemetered - Valid": 
                            Valid++;
                        break;
                    case "Telemetered - Not Updated":
                        NotUpdated++;
                        break;
                    case "Telemetered - Invalid":
                        Invalid++;
                        break;
                    default:
                        break;
                }
            }
            Console.WriteLine();
        }




    }
}
