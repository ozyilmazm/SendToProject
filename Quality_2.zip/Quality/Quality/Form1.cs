﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Interop.CdaDoi;
using Interop.ScadaScripting;
using ASRNSClientLib;
using Interop.SPCSystemConfiguration;

namespace Quality
{
    
    public partial class Form1 : Form
    {
        public static CxCdaDoiConnection Connection;

        internal static Dictionary<string, Station> Stations { get; set; } = new Dictionary<string, Station>();

        public Form1()
        {
            InitializeComponent();

        }

        public void Form1_Load(object sender, EventArgs e)
        {
            
            try
            {
                Connection = new CxCdaDoiConnection();
                Connection.Connect("PSOS", "RT");
                DORConnectionOK.Checked = true;
               

            }
            catch (Exception)
            {
                DORConnectionOK.Checked = false;
            }

            try
            {
                ScadaScriptComponent scada = new ScadaScriptComponentClass();
                scada.ConsoleName = Environment.MachineName;
                scada.UserName = Environment.UserName;
                scada.ContextName = "RT";
                scada.SetActive(1);
                ScadaConnectOK.Checked = true;
            }
            catch (Exception)
            {
                ScadaConnectOK.Checked = false;
            }
            NameService.init();

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void statusStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            listView1.Items.Clear();
            if (Filter.Text.Length <= 0)
            {
                MessageBox.Show("Lütfen bir filtre giriniz.");
            }
            else
            {
                Export.filtertext = Filter.Text;
                CxCdaDoiCommand DoiCommand;
                DoiCommand = Connection.GetCommandObj();
                DoiCommand.AddPrimaryType("Substation", 0);
                DoiCommand.AddAttribute("Substation.Path");
                DoiCommand.AddAttribute("Substation.ObjectID");
                DoiCommand.AddGenericFilter($"PATH(P0000.IID,P0000.StartDate, P0000.JobID) like '%{Filter.Text}%'");

                CxCdaDoiRecordset QueryResult;
                QueryResult = Connection.GetCdaDoiRecordset(DoiCommand);
                if (QueryResult.GetCount() == 0)
                {
                    var result = MessageBox.Show
                    (
                    "Bulunamadı. \n Yeni bir sorgulama yapmak ister misiniz?",
                    "Filter Error!",
                    MessageBoxButtons.YesNo
                    );
                    switch (result)
                    {
                        case DialogResult.No:
                            System.Windows.Forms.Application.Exit();
                            break;
                        default:
                            break;
                    }
                }

                while (QueryResult.IsEOF() == 0)
                {

                        Station station = new Station(QueryResult.GetAttribute("Substation.ObjectID"), QueryResult.GetAttribute("Substation.Path"));

                        station.QualityCounter();
                        Stations.Add(station.ObjId, station);

                        ListViewItem listitem = new ListViewItem(station.ObjId);
                        listitem.SubItems.Add(station.Path);
                        listitem.SubItems.Add(station.Total.ToString());
                        listitem.SubItems.Add(station.Valid.ToString());
                        listitem.SubItems.Add(station.Invalid.ToString());
                        listitem.SubItems.Add(station.NotUpdated.ToString());

                        if (station.Total > 0)
                        {
                            listitem.SubItems.Add($"%{(station.Valid * 100 / station.Total ).ToString()}");
                        }
                        else
                        {
                            listitem.SubItems.Add("0");
                        }
                        
                        listView1.Items.Add(listitem);
            
                    
                    QueryResult.MoveNext();
                }
            }

        }

        private void ExportToExcelButton(object sender, EventArgs e)
        {
            if (listView1.Items.Count > 0)
            {
                int selected = listView1.SelectedItems.Count;
                List<Station> stationsx = new List<Station>();
                for (int i = 0; i < selected; i++)
                {
                    stationsx.Add(Stations[listView1.SelectedItems[i].Text]);
                }
                Export.ExcelExport(stationsx);
            }
            else
            {
                MessageBox.Show("Herhangi bir filtre girilmemiş. Boş liste exportu alınamaz.");
            }
        }

        private void Filter_TextChanged(object sender, EventArgs e)
        {

        }
    }


}

