﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Interop.ScadaScripting;

namespace Quality
{
    class Signal
    {

        public string Path { get; set; }
        public string ObjId { get; set; }
        public string Quality { get; set; }
        public IxAnalogMeasurement analogMeasurement { get; set; }
        public DigitalMeasurementClass digitalMeasurement { get; set; }

        public Signal(string type, string objid)
        {
            if (type == "Analog")
            {
                analogMeasurement = new AnalogMeasurementClass();
                analogMeasurement.ObjectIdStr = objid;
                Quality = CalculateQuality(analogMeasurement.IsValidValue(), analogMeasurement.IsUsableValue(), analogMeasurement.IsUpdatedValue(), analogMeasurement.IsBlocked(), analogMeasurement.IsCalculatedValue(), analogMeasurement.IsEnteredValue(), analogMeasurement.IsEstimatedValue());
                this.Path = analogMeasurement.ObjectPath;
            }
            if (type == "Discrete")
            {
               
                try
                {
                    digitalMeasurement = new DigitalMeasurementClass();
                    digitalMeasurement.ObjectIdStr = objid;
                    Quality = CalculateQuality(digitalMeasurement.IsValidValue(), digitalMeasurement.IsUsableValue(), digitalMeasurement.IsUpdatedValue(), digitalMeasurement.IsBlocked(), digitalMeasurement.IsCalculatedValue(), digitalMeasurement.IsEnteredValue(), digitalMeasurement.IsEstimatedValue());
                    this.Path = digitalMeasurement.ObjectPath;
                }
                catch (Exception)
                {

                }
                
            }
        }
        private string CalculateQuality(bool Valid, bool Usable, bool Updated, bool Blocked, bool Calculated, bool Entered, bool Estimated)
        {
            string source = "Unknown";
            string quality = "Unknown";

            if (Calculated) { source = "Calculated - "; } else if (Entered) { source = "Entered - "; } else if (Estimated) { source = "Estimated - "; } else { source = "Telemetered - "; }

            if (!Valid) { quality = "Invalid"; } else if (!Usable) { quality = "Suspect"; } else if (Blocked) { quality = "Blocked"; } else if (Updated) { quality = "Valid"; } else { quality = "Not Updated"; }

            return (source + quality);
        }
    }
}
