﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace Quality
{
    static class Export
    {
        public static string filtertext { get; set; }
        public static void ExcelExport(List<Station> stations)
        {
           
            string FileName, TemplatePath;
            DateTime ExportDate = DateTime.Now;
            DirectorySecurity securityRules = new DirectorySecurity();
            securityRules.AddAccessRule(new FileSystemAccessRule("Users", FileSystemRights.FullControl, AccessControlType.Allow));

            string ExePath = System.Reflection.Assembly.GetEntryAssembly().Location.Replace(System.AppDomain.CurrentDomain.FriendlyName, "");

            FileName = $"DataQualityReport_{DateTime.Now.Year.ToString()}-{DateTime.Now.Month.ToString()}-{DateTime.Now.Day.ToString()}-{DateTime.Now.Hour.ToString()}-{DateTime.Now.Minute.ToString()}";

            //TemplatePath = @"D:\RAPORLAR\StationQuality\Template\DataQuality.xlsx";
            TemplatePath = ExePath + "DataQuality_Template.xlsx";
            Excel.Application Template = null;
            Excel.Workbooks xDocuments = null;
            Excel.Workbook xDocument = null;
            Excel.Sheets Pages = null;
            Excel.Worksheet Page = null;

            Template = new Excel.Application();
            xDocuments = Template.Workbooks;
            xDocument = xDocuments.Open(@TemplatePath);
            if (xDocument != null)
            {
                Pages = xDocument.Worksheets;
                Page = (Excel.Worksheet)Pages["DATA"];
                try
                {
                    foreach (var obj in stations)
                    {
                        Range line = (Range)Page.Rows[2];
                        line.Insert();
                        Page.Cells[2, 2] = obj.Path;
                        Page.Cells[2, 3] = obj.Total;
                        Page.Cells[2, 4] = obj.Valid;
                        Page.Cells[2, 5] = obj.Invalid;
                        Page.Cells[2, 6] = obj.NotUpdated;
                        var xlSheets = xDocument.Sheets as Excel.Sheets;
                        var xlNewSheet = (Excel.Worksheet)xlSheets.Add(After: xlSheets[xlSheets.Count]);
                        xlNewSheet.Name = obj.Path.Split('/').Last();
                        xlNewSheet.Cells[1, 1] = "PATH";
                        xlNewSheet.Cells[1, 2] = "QUALITY";
                        xlNewSheet.Cells[1, 1].EntireRow.Font.Bold = true;
                        int rownum = 2;
                        foreach (var item in obj.signals.Values)
                        {
                            xlNewSheet.Cells[rownum, 1] = item.Path;
                            xlNewSheet.Cells[rownum, 2] = item.Quality;
                            rownum++;
                        }

                       
                        
                    }
                }
                catch(Exception e)
                {
                    MessageBox.Show(e.ToString());
                }
                
                string xPath = ExePath + "Report";
                
                if (!Directory.Exists(@xPath))
                {
                    
                    Directory.CreateDirectory(@xPath , securityRules);
                }
                
                xPath = xPath + @"\" + ExportDate.Month;
                if (!Directory.Exists(xPath))
                {
                    Directory.CreateDirectory(xPath, securityRules);
                }
                
                if (System.IO.File.Exists(xPath + @"\" + FileName + ".xlsx"))
                {
                    System.IO.File.Delete(xPath + @"\" + FileName + ".xlsx");
                }
                xDocument.SaveAs(xPath + @"\" + FileName + ".xlsx");
                xDocument.Close(0);
                Template.Quit();
                Marshal.ReleaseComObject(Page);
                Marshal.ReleaseComObject(Pages);
                Marshal.ReleaseComObject(xDocument);
                Marshal.ReleaseComObject(xDocuments);
                Marshal.ReleaseComObject(Template);
                Process.Start(xPath + @"\" + FileName + ".xlsx");
                var result = MessageBox.Show
                    (
                    "Export alındı. \n Yeni bir sorgulama yapmak ister misiniz?",
                    "OK",
                    MessageBoxButtons.YesNo
                    );
                switch (result)
                {
                    case DialogResult.No:
                        System.Windows.Forms.Application.Exit();
                        break;
                    default:
                        break;
                }
            }
            else
            {
                MessageBox.Show("Template dokümanı bulunamadı/açılamadı.");
            }
        }

    }
}
