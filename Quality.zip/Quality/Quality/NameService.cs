﻿using ASRNSClientLib;
using Interop.SPCSystemConfiguration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quality
{
    static class NameService
    {

        public static CxASRNSClient m_AsrNSClient;
        public static List<string> signals_digi;
        public static List<string> signals_ana;
        public static void init()

        {
            m_AsrNSClient = new CxASRNSClientClass();
            m_AsrNSClient.ConnectToNS("RT", eASRThinClientHostAccessOrder.TCHAO_Default, "");
        }

        public static List<string> ChildObjectAna (string ssobjid)
        {
            //analog type id
            string analog_type_id = "{2513b44c-1c64-11d4-81e3-00105a24673a}";
            //analog signals list
            signals_ana = new List<string>();
            //get signals guid
            NS_WANTED_VALUES wantedValues = GetWantedValues() | NS_WANTED_VALUES.NS_ObjID;
            object err;

            IxASRNSRecordSet asrNSRecordSet_ana = m_AsrNSClient.GetOffSpringObjects(ssobjid, analog_type_id, string.Empty, 1, wantedValues, out err);
            CheckResult(err);

            if (asrNSRecordSet_ana != null && asrNSRecordSet_ana.IsEOF() == 0)
            {
                try
                {
                    asrNSRecordSet_ana.MoveFirst();

                    for (int i = asrNSRecordSet_ana.GetCount() - 1; i >= 0; --i)
                    {
                        signals_ana.Add(asrNSRecordSet_ana.GetStringValue(NS_WANTED_VALUES.NS_ObjID));
                        asrNSRecordSet_ana.MoveNext();
                    }
                }
                catch
                {   
                }               
            }
            return signals_ana;
        }

        public static List<string> ChildObjectDigi(string ssobjid)
        {
            string digital_type_id = "{7f0589b4-9fb9-4aff-8f4e-ecfe534c4cb9}";

            signals_digi = new List<string>();

            NS_WANTED_VALUES wantedValues = GetWantedValues() | NS_WANTED_VALUES.NS_ObjID;
            object err;
            
            IxASRNSRecordSet asrNSRecordSet_digi = m_AsrNSClient.GetOffSpringObjects(ssobjid, digital_type_id, string.Empty, 1, wantedValues, out err);
            CheckResult(err);

            if (asrNSRecordSet_digi != null && asrNSRecordSet_digi.IsEOF() == 0)
            {
                try
                {
                    asrNSRecordSet_digi.MoveFirst();
                    for (int i = asrNSRecordSet_digi.GetCount() - 1; i >= 0; --i)
                    {
                        signals_digi.Add(asrNSRecordSet_digi.GetStringValue(NS_WANTED_VALUES.NS_ObjID));
                        asrNSRecordSet_digi.MoveNext();
                    }
                }
                catch
                {
                }
            }
            return signals_digi;
        }


        private static void CheckResult(object result)
        {
            if (result == null) throw new ArgumentNullException();
            int retCode = Convert.ToInt32(result);
            if (retCode != 0)
            {
                string errMsg = null;
                switch ((__MIDL___MIDL_itf_ASRNSClient_0000_0000_0001)retCode)
                {
                    case __MIDL___MIDL_itf_ASRNSClient_0000_0000_0001.E_ASRNS_CLT_ALREADY_CONNECTED:
                        errMsg = "ASR NameService client already connected."; break;
                    case __MIDL___MIDL_itf_ASRNSClient_0000_0000_0001.E_ASRNS_CLT_CANNOT_SETUP_COMM:
                        errMsg = "ASR NameService client cannot establish communication with ASR Nameservice server."; break;
                    case __MIDL___MIDL_itf_ASRNSClient_0000_0000_0001.E_ASRNS_CLT_CONTEXT_NOT_EXISTS:
                        errMsg = "Context does not exist."; break;
                    case __MIDL___MIDL_itf_ASRNSClient_0000_0000_0001.E_ASRNS_CLT_INTERNAL_DATAERROR:
                        errMsg = "ASR Nameservice client reported an internal data error."; break;
                    case __MIDL___MIDL_itf_ASRNSClient_0000_0000_0001.E_ASRNS_CLT_INVALID_RESPONSE:
                        errMsg = "ASR Nameservice client reported an invalid server response."; break;
                    case __MIDL___MIDL_itf_ASRNSClient_0000_0000_0001.E_ASRNS_CLT_INVALIDARG:
                        errMsg = "ASR Nameservice client reported an invalid argument"; break;
                    case __MIDL___MIDL_itf_ASRNSClient_0000_0000_0001.E_ASRNS_CLT_NOT_CONNECTED:
                        errMsg = "ASR NameService client is not connected."; break;
                    case __MIDL___MIDL_itf_ASRNSClient_0000_0000_0001.E_ASRNS_CLT_NOVALID_RECORDSET:
                        errMsg = "Invalid recordset."; break;
                    case __MIDL___MIDL_itf_ASRNSClient_0000_0000_0001.E_ASRNS_SVR_INVALID_REQUEST:
                        errMsg = "Invalid client request."; break;
                    case __MIDL___MIDL_itf_ASRNSClient_0000_0000_0001.E_ASRNS_SVR_INVALIDARG:
                        errMsg = "ASR Nameservice Server reported an invaid argument"; break;
                    case __MIDL___MIDL_itf_ASRNSClient_0000_0000_0001.E_ASRNS_SVR_NOTFOUND:
                        errMsg = "The given object was not found."; break;
                    case __MIDL___MIDL_itf_ASRNSClient_0000_0000_0001.E_ASRNS_SVR_NOTFOUND_AND_ACTIVATION_PENDING:
                        errMsg = "The given object was not found and an activation is pending."; break;
                    case __MIDL___MIDL_itf_ASRNSClient_0000_0000_0001.E_ASRNS_SVR_NOVALID_OUTPUT:
                        errMsg = "No valid output."; break;
                    case __MIDL___MIDL_itf_ASRNSClient_0000_0000_0001.E_ASRNS_SVR_OBJECT_POINTER:
                        errMsg = "Object pointer error."; break;
                    case __MIDL___MIDL_itf_ASRNSClient_0000_0000_0001.E_ASRNS_SVR_TOO_MANY_OBJECTS:
                        errMsg = "Too many objects."; break;
                    case __MIDL___MIDL_itf_ASRNSClient_0000_0000_0001.E_ASRNS_SVR_TYPE_POINTER:
                        errMsg = "Type pointer error."; break;
                    default:
                        errMsg = string.Format("An unspecified error occured. Error Code: {0}", retCode); break;
                }
                throw new Exception(errMsg);
            }
        }
        private static NS_WANTED_VALUES GetWantedValues()
        {
            return (NS_WANTED_VALUES.NS_ObjName
                  | NS_WANTED_VALUES.NS_ObjNamePath
                  | NS_WANTED_VALUES.NS_TypeID
                  | NS_WANTED_VALUES.NS_TypeName
                  | NS_WANTED_VALUES.NS_ParentObjID
                  | NS_WANTED_VALUES.NS_ParentTypeID);
        }
    }
}
